#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
#define OVERFLOW -2

#define INIT_SIZE 100
#define INCREMENT 50

typedef int Status;
typedef int ElemType;
typedef int Bool;

typedef struct SqStack
{
	ElemType *top;
	ElemType *base;
	int stacksize;
}SqStack;

Status InitSqStack(SqStack*);
Status Pop(SqStack*,ElemType*);	
Status Push(SqStack*,ElemType);
Status Clear(SqStack*);
Status Destory(SqStack*);
Status IsEmptySq(SqStack);
int Length(SqStack);
Status GetTop(SqStack,ElemType*);

Status Traverse(SqStack, Status (*visit)(ElemType));
Status Print(ElemType);
