#include <stdio.h>
#include <stdlib.h>
#include "seq_stack.h"

Status InitSqStack(SqStack *S)
{
	S->base = (ElemType *)malloc(sizeof(ElemType)*INIT_SIZE);
	S->top = S->base;
	S->stacksize = INIT_SIZE;
	return OK;
} 

Status Push(SqStack *S, ElemType e)
{
	if(S->top-S->base >= S->stacksize){
		S->base = (ElemType *)realloc(S->base, 
			sizeof(ElemType)*(S->stacksize+INCREMENT));
		if(!S->base)	exit(OVERFLOW);
	
		S->top = S->base + S->stacksize;
		S->stacksize += INCREMENT;
	}
	*(S->top) = e;
	S->top++;
	return OK;
}

Status Pop(SqStack *S, ElemType *e)
{
	if(IsEmptySq(*S)) return ERROR;
	S->top--;
	*e = *(S->top); 
	return OK;
}

Bool IsEmptySq(SqStack S)
{
	return S.top == S.base;
}

Status GetTop(SqStack S, ElemType *e)
{
	if(IsEmptySq(S)) return ERROR;
	*e = *(S.top-1);
	return OK;
}

Status Traverse(SqStack S, Status (*visit)(ElemType e))
{
	ElemType *p;
	for(p=S.base; p<S.top; p++)
	{
		visit(*p);
	}
	return OK;
}

Status Print(ElemType e)
{
	printf("%d\n", e);
	return OK;
}
