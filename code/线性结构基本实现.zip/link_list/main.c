#include <stdio.h>
#include <stdlib.h>
#include "linked_list.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void) {
	linked_list La = Create_List_Back();
	linked_list Lb = Create_List_Fore();
	//init_linked_list(&L);
	//creat_from_head(L);
	union_List(La, Lb);
	Elem_type e;
	//delete_linked_list(L, 2, &e);
	traverse_linked_list(La,Print);
	
	return 0;
}
