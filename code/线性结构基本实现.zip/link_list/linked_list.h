#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
#define OVERFLOW -2

typedef int Status;
typedef int Elem_type;

typedef struct linked_node
{
	Elem_type data;
	struct linked_node * next;
}linked_node;
typedef linked_node * linked_list;

Status init_linked_list(linked_list*);
Status creat_from_head(linked_list);
linked_list Create_List_Fore(void);
linked_list Create_List_Back ( void );
Status insert_linked_list(linked_list, int, Elem_type);
Status delete_linked_list(linked_list, int, Elem_type*);
Status traverse_linked_list(linked_list,Status(*visit)(Elem_type));
Status find(linked_list, Elem_type);
void union_List(linked_list, linked_list);
Status Print(Elem_type);
void merge_list(linked_list, linked_list, linked_list);
