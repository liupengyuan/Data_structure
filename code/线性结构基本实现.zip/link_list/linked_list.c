#include <stdio.h>
#include <stdlib.h>
#include "linked_list.h"
//��ͷ���� 
Status init_linked_list(linked_list * L)
{
	//linked_node * p;//    Ϊɶ��p��Ȼ����ָ���У��� 
	*L = (linked_node*)malloc(sizeof(linked_node));
	if(!*L) exit(OVERFLOW);
	(*L)->next = NULL; 
	//(*L)->next = p;
	
	return OK;
}

Status creat_from_head(linked_list L)
{
	int e;
	while(scanf("%d,",&e) && e!=-1)
	{
		insert_linked_list(L, 1, e);
	}
	return OK;
}

Status insert_linked_list(linked_list L, int i, Elem_type e)
{
	linked_node * p = L;
	int j=0;
	while(j<i-1&&p)
	{
		j++;
		p=p->next;
	}
	if(j>i-1||!p) return ERROR;
	linked_node * new_node = (linked_node*)malloc(sizeof(linked_node));
	if(!new_node) exit(OVERFLOW);
	
	new_node->data = e;
	new_node->next = p->next;
	p->next = new_node;
	
	return OK;
} 

Status traverse_linked_list(linked_list L, Status(*visit)(Elem_type e))
{
	linked_node * p = L->next;
	while(p)
	{
		visit(p->data);
		p=p->next;
	}
	return OK;
}

Status delete_linked_list(linked_list L, int i, Elem_type * e)
{
	linked_node * p = L, * q;
	int j=0;
	while(p&&j<i-1)
	{
		j++;
		p=p->next;
	}

	if(j>i-1||!p||!p->next) return ERROR;
	q = p->next;
	p->next = q->next;
	*e = q->data;
	free(q);
	return OK;
}

Status Print(Elem_type e)
{
	printf("%d\n", e);
	return OK;
}

linked_list Create_List_Fore ( void ) {
     char ch;   
	 linked_node* new_node; 
     linked_list first = (linked_list)malloc(sizeof(linked_node));
     first->next = NULL;
     while ((ch = getchar()) != '\n') {
          new_node = (linked_list)malloc(sizeof(linked_node));
          new_node->data = ch;                
          new_node->next = first->next;  //ͷ�巨���벽��
          first->next = new_node;
     }
     return first;
}

linked_list Create_List_Back ( void ) 
{
    linked_list  first = (linked_list)malloc(sizeof(linked_node));
	char ch;   
	linked_node* new_node, *rear=first; 
    first->next = NULL;
    while ((ch = getchar()) != '\n') 
	{
        new_node = (linked_list)malloc(sizeof(linked_node));
        new_node->data = ch;                
        rear->next = new_node;//β�巨���벽��
		rear = new_node;		//ʼ��ָ��β�ڵ�
    }
	rear->next = NULL;		//β�ڵ�ָ��
    return first;
}

void union_List(linked_list La, linked_list Lb)
{
	linked_node *p = Lb->next;
	Elem_type e;
    while (p)  
	{  
		e = p->data;   
		p = p->next;
		if(!find(La, e))
	        insert_linked_list(La, 1, e); 
	}
} 

Status find(linked_list L, Elem_type e)
{
	linked_list p=L->next;
	while(p)
	{
		if(p->data==e)
			return OK;
		p = p->next;
	}
	return ERROR;
}

void merge_list(linked_list La, linked_list Lb, linked_list Lc)
{
	linked_list pa = La->next; 
	linked_list pb = Lb->next, pc;
	Lc = pc = La;
	while(pa&&pb) 
	{
		if(pa->data<=pb->data)
		{
			pc->next = pa; 
			pc = pa;
			pa=pa->next;
		}
		else
		{
			pc->next = pb; 
			pc = pb;
			pb=pb->next;
		}
	}
	pc->next = pa?pa:pb;//����ʣ������Ԫ��free(Lb);
}
 
