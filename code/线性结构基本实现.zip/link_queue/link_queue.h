#define MAX_SIZE 100
#define INIT_SIZE 50
#define INCRE_SIZE 10
#define OK 1
#define ERROR -1
#define Status int
#define OVERFLOW -2
#define OK 1
#define ElemType int
#define Bool int

typedef struct LinkQueNode{
	ElemType data;
	struct LinkQueNode * next;
}LinkQueNode;

typedef struct LinkQueue{
	LinkQueNode *front;
	LinkQueNode *rear;
}LinkQueue;

Status InitLinkQueue(LinkQueue *);
Status EnLinkQueue(LinkQueue*, ElemType);
Status DeLinkQueue(LinkQueue*, ElemType *);
Bool Is_empty (LinkQueue); 
Status GetTop(LinkQueue, ElemType *);
void Traverse(LinkQueue);
