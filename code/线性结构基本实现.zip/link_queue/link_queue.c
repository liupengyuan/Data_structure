#include <stdio.h>
#include <stdlib.h>
#include "link_queue.h"

Status InitLinkQueue(LinkQueue *Q)
{
	Q->front = Q->rear = NULL;
	return OK;
}

Status EnLinkQueue(LinkQueue *Q, ElemType e)
{
	LinkQueNode *p = (LinkQueNode *)malloc(sizeof(LinkQueNode));
	if(!p) exit(OVERFLOW);
	p->data = e;	p->next = NULL;
	if(Is_empty(*Q))
		Q->rear = Q->front = p;
	else{
		Q->rear->next = p;
		Q->rear = p;
	}
	return OK;
}

Status DeLinkQueue(LinkQueue *Q, ElemType *e)
{
	if ( Is_empty(*Q) ) return ERROR;
	LinkQueNode *p = Q->front;
	Q->front = Q->front->next;
	if ( Q->front == NULL ) Q->rear = NULL;
	*e = p->data;
	free(p);
	return OK;
}

void Traverse(LinkQueue Q)
{
	while(Q.front!=Q.rear){
		printf("%d\n",Q.front->data);
		Q.front = Q.front->next;
	}
}

Bool Is_empty(LinkQueue Q)
{
	return Q.front == NULL;
}
