#include <stdio.h>
#include <stdlib.h>
#include "link_queue.h"


/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void) {
	LinkQueue Q;
	InitLinkQueue(&Q);
	EnLinkQueue(&Q, 10);
	EnLinkQueue(&Q, 9);
	EnLinkQueue(&Q, 8);
	int e;
	DeLinkQueue(&Q, &e);
	printf("%d\n",e);
	DeLinkQueue(&Q, &e);
	printf("%d\n",e);
	DeLinkQueue(&Q, &e);
	printf("%d\n",e);
	return 0;
}
