#include <stdio.h>
#include <stdlib.h>
#include "link_stack.h"

Status InitLinkStack(link_stack *S)
{
	*S = NULL;
	return OK;
}

Status Push(link_stack* S, ElemType e)
{
	link_stack_node *new_node = (link_stack_node*)malloc(sizeof(link_stack_node));
	if(!new_node) return OVERFLOW;
	new_node->data = e;	new_node->next = *S;
	*S=new_node;
	return OK;
}

BOOL Is_empty (link_stack S) 
{
    return S == NULL;
}

Status Pop(link_stack* S, ElemType *e)
{
	if(Is_empty(*S))	return ERROR;
	link_stack_node *p = *S;
	*S = (*S)->next;	*e = p->data;
	free(p);
	return OK;
}
void Traverse(link_stack S)
{
	while(S){
		printf("%d\n",S->data);
		S=S->next;
	}
}

void Traverse_c(link_stack S)
{
	while(S){
		printf("%c",S->data);
		S=S->next;
	}
	printf("\n");
}
void Clear(link_stack *S)
{
	while(*S){
		link_stack_node *p = *S;
		(*S) = (*S)->next;
		free(p);
	}
}

void Destroy(link_stack *S)
{
	while(*S){
		link_stack_node *p = *S;
		(*S) = (*S)->next;
		free(p);
	}
}

Status GetTop(link_stack S, ElemType *e)
{
	if(Is_empty(S)) return ERROR;
	*e = S->data;
	return OK;
}
