#include <stdio.h>
#include <stdlib.h>
#include "link_stack.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void) {
	link_stack S;
	InitLinkStack(&S);
	ElemType e;
	Push(&S, 10);
	Push(&S, 9);
	Push(&S, 8);
	Push(&S, 7);
	Traverse(S);
	Pop(&S, &e);
	printf("--%d\n",e);
	Pop(&S, &e);
	printf("--%d\n",e);
	Traverse(S);
	return 0;
}
