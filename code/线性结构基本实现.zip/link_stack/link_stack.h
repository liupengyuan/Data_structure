#define MAX_SIZE 100
#define INIT_SIZE 50
#define INCRE_SIZE 10
#define OK 1
#define ERROR 0
#define Status int
#define OVERFLOW -2
//#define ElemType char
#define ElemType int
#define BOOL int

typedef struct link_stack_node{
	ElemType data;
	struct link_stack_node * next;
}link_stack_node, *link_stack;

Status InitLinkStack(link_stack *);
Status Push(link_stack*, ElemType);
Status Pop(link_stack*, ElemType*);
Status GetTop(link_stack, ElemType*); 
BOOL Is_empty (link_stack); 
void Traverse(link_stack);
void Traverse_c(link_stack);
void Clear(link_stack *);
void Destroy(link_stack *);
